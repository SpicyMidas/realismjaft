Reverie textures
================

Every texture the mod uses, in the same folders as inside the jar
(assets/reverie/textures/...):

  block/    blocks; block/gearshift/ is the Tuff Gearshift (casing sides, gate plate, frame,
            gearbox face, stick rod and knobs, gear window glyphs)
  item/     items (item/paper_glider_sheet.png is the paper of the 3D glider held while gliding)
  entity/   mobs and the Shades
  gui/      gui/gearshift.png is the gearshift screen (plate, knobs, lamps, tuff tile, title board)
  environment/, particle/, mob_effect/ ...  sky, particles, effect icons

How to edit and send back
- Keep each file's name, folder and pixel size the same (16x16 stays 16x16, and so on).
- Keep transparency where there is some (the casing frame's open middle, item outlines).
- Files with "_on" are the powered/lit versions; "_sport" the sport gearshift.
- Send back only the files you changed, in the same folders, and I'll put them in the mod.

Many of these are drawn by a script (tools/gen_textures.py); when your versions come back
I'll stop that script from overwriting the ones you edited.
